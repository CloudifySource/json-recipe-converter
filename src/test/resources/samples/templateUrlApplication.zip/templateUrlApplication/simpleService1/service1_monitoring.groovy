 return [
	"Total Requests Count" : 0,
	"Total Connections Count" : 0
]