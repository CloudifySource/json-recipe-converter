println "This is the service1 start detection script"
return true 
