println "This is the service1 post start script"
