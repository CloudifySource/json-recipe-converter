println "This is the service1 pre stop script"
